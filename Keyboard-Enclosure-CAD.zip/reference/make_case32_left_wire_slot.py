"""V1.3: left 52 x 4 mm wire slot, retain Type-C and close unused Pico USB hole."""
import bpy,bmesh,json,math,struct,shutil,hashlib,zipfile
from pathlib import Path
from mathutils import Vector
from mathutils.bvhtree import BVHTree
ROOT=Path(r'F:\codex-project\pcb')
OLD=ROOT/'enclosure_32key_v1_2_no_logo_2026-10-14'
OUT=ROOT/'enclosure_32key_v1_3_left_wire_slot_2026-10-20'
for d in ['', 'STL_print','STL_assembly','renders','reference']:(OUT/d).mkdir(exist_ok=True,parents=True)
bpy.ops.wm.open_mainfile(filepath=str(OLD/'Keyboard_32Key_AllWhite_NoLogo_V1_2.blend'))
sc=bpy.context.scene
base=bpy.data.objects['Nos Pico - Base Left - 32key']
support=bpy.data.objects['Nos Pico - Support Left - 32key']
case=bpy.data.collections['01_CASE_32KEY_PRINTABLE']
def tree(ob):return BVHTree.FromPolygons([ob.matrix_world@v.co for v in ob.data.vertices],[list(p.vertices) for p in ob.data.polygons])
def stats(ob):
 bm=bmesh.new();bm.from_mesh(ob.data);seen=set();n=0
 for v in bm.verts:
  if v in seen:continue
  n+=1;todo=[v];seen.add(v)
  while todo:
   v=todo.pop()
   for e in v.link_edges:
    q=e.other_vert(v)
    if q not in seen:seen.add(q);todo.append(q)
 s={'vertices':len(bm.verts),'faces':len(bm.faces),'nonmanifold_edges':sum(not e.is_manifold for e in bm.edges),'connected_solids':n,'volume_mm3':bm.calc_volume(signed=True),'bounds_mm':[[min(v.co[k] for v in bm.verts) for k in range(3)],[max(v.co[k] for v in bm.verts) for k in range(3)]]}
 bm.free();return s
def remove(ob):
 me=ob.data;bpy.data.objects.remove(ob,do_unlink=True)
 if me.users==0:bpy.data.meshes.remove(me)
def clean(ob):
 bm=bmesh.new();bm.from_mesh(ob.data);bmesh.ops.remove_doubles(bm,verts=list(bm.verts),dist=1e-6);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(ob.data);bm.free();ob.data.update()
def boolean(ob,c,op):
 bpy.context.view_layer.objects.active=ob;m=ob.modifiers.new('Left wire slot '+op,'BOOLEAN');m.operation=op;m.solver='MANIFOLD';m.object=c;bpy.ops.object.modifier_apply(modifier=m.name);remove(c)
def box(name,lo,hi):
 bpy.ops.mesh.primitive_cube_add(size=1,location=[(a+b)/2 for a,b in zip(lo,hi)]);o=bpy.context.object;o.name=name;o.dimensions=[b-a for a,b in zip(lo,hi)];bpy.ops.object.transform_apply(location=False,rotation=False,scale=True);return o
def along_x(t,y,z,start=-190,stop=-175.4):
 h=t.ray_cast(Vector((start,y,z)),Vector((1,0,0)),stop-start)[0]
 return None if h is None else float(h.x)
before={'base':stats(base),'support':stats(support)}
base_before=tree(base);support_before=tree(support)
# Confirm the lower left wall thickness using intact wall beside the old opening.
h1=base_before.ray_cast(Vector((-190,-60,3.85)),Vector((1,0,0)),20)[0]
h2=base_before.ray_cast(h1+Vector((.001,0,0)),Vector((1,0,0)),10)[0]
assert abs(h1.x+182.2)<.001 and abs(h2.x+180.05)<.001,(h1,h2)
# Below the PCB seat the original side wall is 2.15 mm thick.
boolean(base,box('Close unused Pico USB',(-182.2,-58.15,2.45),(-180.05,-49.35,5.25)),'UNION')
clean(base)
# Rounded rectangular slot: Y -64..-12, Z 10..14. Cut all 6.6 mm of side rail.
Y0,Y1,Z0,Z1,R=-64.,-12.,10.,14.,1.
profile=[]
for cy,cz,ang in [(Y1-R,Z1-R,0),(Y0+R,Z1-R,90),(Y0+R,Z0+R,180),(Y1-R,Z0+R,270)]:
 for j in range(17):
  a=math.radians(ang+90*j/16);profile.append((cy+R*math.cos(a),cz+R*math.sin(a)))
n=len(profile);vs=[(x,y,z) for x in [-183.2,-175.3] for y,z in profile]
fs=[list(reversed(range(n))),list(range(n,2*n))]+[(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
me=bpy.data.meshes.new('Rounded side slot cutter');me.from_pydata(vs,[],fs);me.update();cut=bpy.data.objects.new('52x4 R1 slot cutter',me);case.objects.link(cut);clean(cut)
boolean(support,cut,'DIFFERENCE');clean(support)
after={'base':stats(base),'support':stats(support)}
for k,s in after.items():
 assert s['nonmanifold_edges']==0 and s['connected_solids']==1 and s['volume_mm3']>0,(k,s)
 assert all(abs(a-b)<.001 for aa,bb in zip(before[k]['bounds_mm'],s['bounds_mm']) for a,b in zip(aa,bb))
assert after['base']['volume_mm3']>before['base']['volume_mm3']
assert after['support']['volume_mm3']<before['support']['volume_mm3']
base_after=tree(base);support_after=tree(support)
# Check clear rays right through the new wall aperture (not just a shallow recess).
portal_samples=0
for yi in range(207):
 y=-63.75+.25*yi
 for zi in range(15):
  z=10.25+.25*zi
  cy=min(max(y,Y0+R),Y1-R);cz=min(max(z,Z0+R),Z1-R)
  if (y-cy)**2+(z-cz)**2>(R-.03)**2:continue
  assert along_x(support_after,y,z) is None,(y,z,'blocked slot')
  portal_samples+=1
# Type-C contour remains unchanged, including nearby solid wall.
typec_samples=0
for yi in range(57):
 for zi in range(25):
  y=-41+yi*.25;z=2+zi*.25
  a=along_x(base_before,y,z);b=along_x(base_after,y,z)
  assert (a is None and b is None) or (a is not None and b is not None and abs(a-b)<.001),(y,z,a,b)
  typec_samples+=1
# Old connector opening is closed and the adjacent cover screw feature is untouched.
closed_samples=0
for yi in range(29):
 for zi in range(7):
  y=-57.25+.25*yi;z=3+.25*zi
  h=along_x(base_after,y,z)
  assert h is not None and abs(h+182.2)<.001,(y,z,h)
  closed_samples+=1
screw_samples=0
for ix in range(25):
 for iy in range(25):
  x=-177.6+(ix-12)*.25;y=-67.8+(iy-12)*.25
  a=support_before.ray_cast(Vector((x,y,20)),Vector((0,0,-1)),13)[0]
  b=support_after.ray_cast(Vector((x,y,20)),Vector((0,0,-1)),13)[0]
  assert (a is None and b is None) or (a is not None and b is not None and (a-b).length<.001),(x,y,a,b)
  screw_samples+=1
def export_stl(ob,p,ground=False):
 me=ob.data;me.calc_loop_triangles();vs=[ob.matrix_world@v.co for v in me.vertices]
 off=Vector([min(v[k] for v in vs) for k in range(3)]) if ground else Vector((0,0,0))
 with open(p,'wb') as f:
  f.write(b'32 KEY V1.3 LEFT WIRE SLOT - millimetres'.ljust(80,b' '));f.write(struct.pack('<I',len(me.loop_triangles)))
  for t in me.loop_triangles:
   a,b,c=[vs[i]-off for i in t.vertices];nn=(b-a).cross(c-a)
   if nn.length:nn.normalize()
   f.write(struct.pack('<12fH',*nn,*a,*b,*c,0))
changed={'Base_Left_32key.stl':base,'Support_Left_32key.stl':support}
unchanged=[]
for d in ['STL_print','STL_assembly']:
 for p in (OLD/d).glob('*.stl'):
  dest=OUT/d/p.name
  if p.name in changed:export_stl(changed[p.name],dest,d=='STL_print')
  else:
   shutil.copy2(p,dest);assert hashlib.sha256(p.read_bytes()).digest()==hashlib.sha256(dest.read_bytes()).digest();unchanged.append(str(dest.relative_to(OUT)))
assert len(list((OUT/'STL_print').glob('*.stl')))==12
assert len(bpy.data.collections['02_KEYS_32_PREVIEW'].objects)==32
assert not any('BlackKey' in o.name or o.name.startswith('Panel Center - Inlay ') for o in bpy.data.objects)
report={'version':'V1.3','date':'2026-10-20','source':str(OLD/'Keyboard_32Key_AllWhite_NoLogo_V1_2.blend'),'user_size_interpretation':'About six old USB openings end to end: 6 x 8.6 = 51.6 mm, rounded to 52 mm. Height enlarged to 4 mm for wiring.','slot':{'length_mm':52,'height_mm':4,'corner_radius_mm':1,'y_range_mm':[Y0,Y1],'z_range_mm':[Z0,Z1],'through_side_wall_mm':6.6,'bottom_gap_above_pcb_top_mm':2,'minimum_vertical_gap_above_typec_opening_mm':2.75},'old_unused_usb_hole':{'width_mm':8.6,'height_mm':2.6,'status':'Filled flush to original 2.15 mm base wall'},'before':before,'after':after,'checks':{'watertight_changed_parts':True,'one_solid_per_changed_part':True,'slot_clear_ray_samples':portal_samples,'typec_unchanged_ray_samples':typec_samples,'unused_hole_closed_ray_samples':closed_samples,'nearby_screw_unchanged_ray_samples':screw_samples},'unchanged_files_sha256_verified':unchanged,'limitations':['This change provides a wire exit only. Header/cable height and key travel still need hardware fit validation.','Slot dimension is a design assumption based on the user approximate six USB openings request; connector dimensions were not supplied.']}
(OUT/'reference/left_wire_slot_checks.json').write_text(json.dumps(report,indent=2),encoding='utf8')
readme=(OLD/'README.txt').read_text(encoding='utf8').replace('32键全白无标识外壳初版 V1.2','32键全白无标识外壳 V1.3（左侧走线槽）').replace('（2026-10-14）','（2026-10-20）',1).replace('Keyboard_32Key_AllWhite_NoLogo_V1_2.blend','Keyboard_32Key_LeftWireSlot_V1_3.blend').replace('renders/03_header_reserved_space.png','renders/04_header_reserved_space_reference.png')
shutil.copy2(OLD/'renders/03_header_reserved_space.png',OUT/'renders/04_header_reserved_space_reference.png')
readme+='\nV1.3改动（2026-10-20）：\n- 左侧上半部新增52×4mm贯通走线槽，四角R1；按6个原闲置USB孔并排长度51.6mm取整设计，高度放宽到4mm。\n- 走线槽底边距底面10mm、顶边14mm；与Type-C开口顶部保留2.75mm壁料；槽底高于PCB顶面2mm。\n- Type-C开口保留，旧的8.6×2.6mm闲置Pico USB孔封平。\n- 本次修改的打印件只有Base_Left_32key.stl与Support_Left_32key.stl，其余10种打印模型沿用V1.2。\n- 走线槽已验证贯通；两件修改件为封闭实体，Type-C孔及相邻固定孔几何检查通过。\n- 走线槽不代表排针高度和按键全行程干涉已解决；这些装配条件仍需确认。\n'
(OUT/'README.txt').write_text(readme,encoding='utf8')
sc['version']='32-key all white no logo LEFT WIRE SLOT V1.3 2026-10-20'
sc['left_wire_slot_mm']='52 x 4, R1; Y -64..-12, Z 10..14; Type-C gap 2.75'
cam=sc.camera;saved=(cam.location.copy(),cam.rotation_euler.copy(),cam.data.ortho_scale,sc.render.resolution_x,sc.render.resolution_y)
sc.render.filepath=str(OUT/'renders/01_assembly_left_wire_slot.png');bpy.ops.render.render(write_still=True)
cam.location=(-400,-42,12);cam.rotation_euler=(Vector((-180,-42,12))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=100
sc.render.resolution_x=1800;sc.render.resolution_y=760
sc.render.filepath=str(OUT/'renders/02_left_side_wire_slot.png');bpy.ops.render.render(write_still=True)
cam.location=(-280,-130,85);cam.rotation_euler=(Vector((-165,-46,10))-cam.location).to_track_quat('-Z','Y').to_euler();cam.data.ortho_scale=110
sc.render.filepath=str(OUT/'renders/03_left_slot_oblique.png');bpy.ops.render.render(write_still=True)
cam.location,cam.rotation_euler,cam.data.ortho_scale,sc.render.resolution_x,sc.render.resolution_y=saved
for area in bpy.context.screen.areas if bpy.context.screen else []:
 if area.type=='VIEW_3D':area.spaces.active.overlay.show_overlays=False
for ob in bpy.context.selected_objects:ob.select_set(False)
bpy.ops.wm.save_as_mainfile(filepath=str(OUT/'Keyboard_32Key_LeftWireSlot_V1_3.blend'))
delivery=ROOT/'32键外壳_全白无Logo_左侧走线槽_V1.3.blend';shutil.copy2(OUT/'Keyboard_32Key_LeftWireSlot_V1_3.blend',delivery)
assert hashlib.sha256(delivery.read_bytes()).digest()==hashlib.sha256((OUT/'Keyboard_32Key_LeftWireSlot_V1_3.blend').read_bytes()).digest()
lines=['32键全白无Logo V1.3 左侧走线槽打印包','模型单位：毫米。仍为试装版本。','本次修改：左侧52×4mm圆角走线槽；保留Type-C，封闭闲置USB孔。','若已有V1.2文件，本次仅替换左底座 Base_Left_32key.stl 和左支架 Support_Left_32key.stl。','','整套数量：']
for p in sorted((OUT/'STL_print').glob('*.stl')):lines.append(f"{32 if p.name.startswith('Key_') else 1} 件  {p.name}")
lines+=['','整套为32个琴键加11个外壳零件，共43件。','最大单件右底座232.2×90×19mm；打印平台需另留必要余量。','排针/线缆高度、琴键行程、弹簧、磁铁仍需实物确认；槽口没有替代这些验证。','切片前按实际材料设定朝向、支撑与收缩补偿。']
(OUT/'打印数量与试装说明.txt').write_text('\n'.join(lines),encoding='utf8')
shutil.copy2(ROOT/'tmp/make_case32_left_wire_slot.py',OUT/'reference/make_case32_left_wire_slot.py')
with zipfile.ZipFile(OUT/'Keyboard_32Key_V1_3_PrintPack_2026-10-20.zip','w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted((OUT/'STL_print').glob('*.stl')):z.write(p,str(p.relative_to(OUT)))
 for p in [OUT/'README.txt',OUT/'打印数量与试装说明.txt',OUT/'renders/01_assembly_left_wire_slot.png',OUT/'renders/02_left_side_wire_slot.png',OUT/'renders/03_left_slot_oblique.png',OUT/'renders/04_header_reserved_space_reference.png']:z.write(p,str(p.relative_to(OUT)))
print('LEFT_SLOT_BUILD_OK',json.dumps(report['checks']),delivery,flush=True)

